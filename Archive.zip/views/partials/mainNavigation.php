<nav class="main-nav">
	<div class="wrapper">
		<img class="float-left mtxs mrxs" src="images/tradewind-logo.png">
		<ul class="unstyled mtn">
			<li><a href="#">Home</a></li>
			<li><a href="#">Architectural Center</a></li>
			<li><a href="#">Gallery</a></li>
			<li><a href="#">About</a></li>
			<li><a href="#">Windows</a></li>
			<li><a href="#">Doors</a></li>
		</ul>
	</div>
</nav>