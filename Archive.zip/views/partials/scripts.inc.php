<script src="/templates/leaf-base/resources/js/jquery.min.js"></script>
<script src="/templates/leaf-base/resources/js/actions.js"></script>